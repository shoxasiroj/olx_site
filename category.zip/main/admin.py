from django.contrib import admin

from .models import AdvUser

admin.site.register(AdvUser)
