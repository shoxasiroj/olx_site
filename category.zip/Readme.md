
# OLX platformasi

### Ushbu pet proyekt python dasturlash tilining Django web frameworkida yaratilgan. 
#### Ushu proyektda:
##### platformadan Ro'yxatdan o'tish
##### Ro'hatdan otish uchun to'ldirilgan email-ga xabar yuborish
##### Akkauntni aktivatsiya qilish uchun email-ga ilova yuborish
##### Parolni yangilash
##### Shaxsiy Akkaunt
##### Mahsulotlar Sahifasi
##### Admin panel va hkz
#### funksiyalar ishlab chiqilgan




# Hi, I'm Shaxobiddin! 👋

